<?php

return [
    'dash'  => 'الرىْيسية',
    'content'  => 'اتصل بنا',
    'logout'  => 'تسجيل خروج',
    'lang'  => 'الغة',
    'clints'    => 'العملاء',

    'user'  => 'الاعضاء',
    'image' => 'الصورة',
    'user_table'  => 'جدول الاعضاء',
    'first_name'    => 'الاسم الاول',
    'last_name' => 'الاسم الاخير',
    'email' => 'الايميل',


    'action'    => 'اكشن',
    'no_user'   => 'للاسف لا يوجد اعضاء يمكنك اضافة اعضاء جدد يسهولة',
    'edit'    => 'تعديل',
    'delete'    => 'حدف',
    'add_member'    => 'اضافة عضو',

    'create'    => 'اضافة عضو',

    'password'  => 'كلمة المرور',
    'confirm_password'  => 'تاكيد كلمة السر',
    'chose_file'    => 'اختر صورة',

    'status'    => 'الحالة',

    'profit'    => 'الربح',
];
