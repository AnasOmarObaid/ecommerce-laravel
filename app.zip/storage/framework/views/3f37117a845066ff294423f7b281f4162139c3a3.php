<?php /* C:\xampp\htdocs\EcommerceProject\ecommerce\resources\views/layouts/Dashboard/Users/index.blade.php */ ?>
<?php $__env->startSection('app'); ?>
<?php if(session()->get('successfully')): ?>
<div class="noti-message alert-success"><i class="far fa-check-circle" style="font-size: 14px;"></i>
    <?php echo e(session()->get('successfully')); ?> </div>
<?php endif; ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">

        <div class="row mb-2">
            <div class="col-sm-6">
                <h2 class="m-0 text-dark"><?php echo app('translator')->getFromJson('site.user'); ?></h2>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('dashboard/home')); ?>"><?php echo app('translator')->getFromJson('site.dash'); ?></a></li>
                    <li class="breadcrumb-item"><?php echo app('translator')->getFromJson('site.user'); ?></li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<div class="container-fluid">
    <?php if(auth()->user()->can(['create-users|delete-users|update-users|read-users'])): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card" style="overflow: hidden;">
                <div class="card-header" style="position: relative">
                    <h3 class="card-title"><?php echo app('translator')->getFromJson('site.user_table'); ?></h3>
                    <?php if(auth()->user()->can(['create-users'])): ?>
                    <a class="btn btn-success btn-sm" href="<?php echo e(url('dashboard/user/create')); ?>"
                        style="cursor: pointer;float: right;"><i class="fas fa-user-plus fa-fw"></i>
                        <?php echo app('translator')->getFromJson('site.add_member'); ?></a>
                    <?php else: ?>
                    <a class="btn btn-success btn-sm disabled" href="#"
                        style="float: inline-end;margin-bottom: -5px;margin-top: -5px; color:white; cursor:pointer"><i
                            class="fas fa-user-plus fa-fw"></i> <?php echo app('translator')->getFromJson('site.add_member'); ?></a>
                    <?php endif; ?>
                    <!-- SEARCH FORM -->
                    <form class="form-inline col-md-6" method="get" action="<?php echo e(url('dashboard/user/show')); ?>">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" type="search" placeholder="Search"
                                aria-label="Search" style="border-right-width: thin;" name="search"
                                value="<?php echo e(old('search')); ?>" />
                            <div class="input-group-append">
                                <button class="btn btn-navbar" type="submit">
                                    <i class="fas fa-search" style="position: absolute;left: -20px;top: 8px;"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <?php if(count($users) <= 0): ?> <?php echo app('translator')->getFromJson('site.no_user'); ?> <?php else: ?> <table
                        class="table table-hover table-bordered text-center">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <td scope="col"><?php echo app('translator')->getFromJson('site.image'); ?></td>
                                <td scope="col"><?php echo app('translator')->getFromJson('site.first_name'); ?></td>
                                <td scope="col"><?php echo app('translator')->getFromJson('site.last_name'); ?></td>
                                <td scope="col"><?php echo app('translator')->getFromJson('site.email'); ?></td>
                                <td scope="col"><?php echo app('translator')->getFromJson('site.action'); ?></td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $number = 0 ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <th><?php echo e(++$number); ?></th>
                                <td>
                                    <?php if($user->image): ?>
                                    <img src="<?php echo e(asset('data\upload\image\users\\') . $user->image); ?>" alt="Image User"
                                        style="max-width: 50px;max-height: 50px;">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('image\users\3926_images.jpg')); ?>" alt=" defult User"
                                        style="max-width: 50px;max-height: 50px;">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($user->first_name); ?></td>
                                <td><?php echo e($user->last_name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php if(auth()->user()->can(['update-users'])): ?>
                                    <a href="<?php echo e(url('dashboard/user/edit', $user->id)); ?>"
                                        class="btn btn-success btn-sm"><i class="fas fa-user-edit fa-fw"></i>
                                        <?php echo app('translator')->getFromJson('site.edit'); ?>
                                    </a>
                                    <?php else: ?>
                                    <a href="#" class="btn btn-success btn-sm disabled"><i
                                            class="fas fa-user-edit fa-fw"></i>
                                        <?php echo app('translator')->getFromJson('site.edit'); ?>
                                    </a>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->can(['delete-users'])): ?>
                                    <form style="display:inline-block" method="post"
                                        action="<?php echo e(route('delete', $user)); ?>">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                            data-target="#example<?php echo e($number); ?>" style="color:white"><i
                                                class="fas fa-user-minus fa-fw"></i>
                                            <?php echo app('translator')->getFromJson('site.delete'); ?>
                                        </button>
                                        <!-- Modal -->
                                        <div class="modal fade" tabindex="-1" role="dialog" id="example<?php echo e($number); ?>"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Delete Members
                                                        </h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close" class="btn-sm">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are You Soure To Delete <?php echo e($user->email); ?> <br>
                                                        This Will Lose The Data For This User
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm"
                                                            data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-danger btn-sm">Save
                                                            changes</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <?php else: ?>
                                    <a class="btn btn-danger btn-sm disabled" href="#"><i
                                            class="fas fa-user-minus fa-fw"></i> <?php echo app('translator')->getFromJson('site.delete'); ?></a>
                                    <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        </table>
                        <div style="margin-top:15px">
                            <?php echo e($users->appends(['search' => request()->get('search')])->links()); ?>

                        </div>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="container">
        <p class="alert alert-danger"> You Dont Have Permation To Created or See The Users </p>
    </div>
    <?php endif; ?>
</div>
<!-- /.content-header -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>