<?php /* C:\xampp\htdocs\EcommerceProject\ecommerce\resources\views/layouts/Dashboard/Order/index.blade.php */ ?>
<?php $__env->startSection('app'); ?>

<?php if(session()->get('successfully')): ?>
<div class="noti-message alert-success"><i class="far fa-check-circle" style="font-size: 14px;"></i>
    <?php echo e(session()->get('successfully')); ?> </div>
<?php endif; ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h2 class="m-0 text-dark"><?php echo app('translator')->getFromJson('site.order'); ?></h2>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('dashboard/home')); ?>"><?php echo app('translator')->getFromJson('site.dash'); ?></a></li>
                    <li class="breadcrumb-item"><?php echo app('translator')->getFromJson('site.order'); ?></li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- End Header Contint(Page header) -->

<!--  Start Contint -->
<div class="container-fluid">
    <section class="order-content">
        <div class="row">
            <div class="col-md-7">
                <!-- Client list -->
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h3 class="card-title" style="margin-top: 6px;font-size: 20px; margin-right:10px">
                            <i class="far fa-chart-bar"></i>
                            Client List
                        </h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                        
                        <form class="col-md-9 form-inline">
                            <div class="form-group">
                                <input type="search" class="form-control" name="search" placeholder="Search" required
                                    value="<?php echo e(request('search') ?? ''); ?>">
                            </div>
                            <div class="float-right" style="margin-left:5px">
                                <button type="submit" class="btn btn-success"> <i class="fas fa-search fa-fw"></i>
                                    Search</button>
                            </div>
                        </form>
                        <!-- /.End Form -->
                    </div>
                    
                    <div class="card-body">
                        <?php if(count($orders) <= 0 ): ?> <p class=" alert alert-danger">There Is No Orders</p>
                            <?php else: ?>
                            <table class="table table-hover">
                                <thead>
                                    <th>Client Name</th>
                                    <th>Price</th>
                                    <th>Add at</th>
                                    <th>Action</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($order->getUser()->first()->first_name . ' '. $order->getUser()->first()->last_name); ?>

                                        </td>
                                        <td><span class="span-price"><?php echo e($order->total_price); ?></span></td>
                                        <td><?php echo e($order->created_at->toFormattedDateString()); ?></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-info get-order"
                                                data-name="<?php echo e($order->getProduct()->first()->name); ?>"
                                                data-quantity="<?php echo e($order->quantity); ?>"
                                                data-price="<?php echo e($order->getProduct()->first()->sale_price); ?>"
                                                data-total="<?php echo e($order->total_price); ?>">
                                                <i class="fas fa-shopping-basket fa-fw">
                                                </i> Show
                                            </a>
                                            <?php if(auth()->user()->can('update-orders')): ?>
                                            <form action="<?php echo e(route('order.edit', $order)); ?>" style="display:inline-block">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <button type="submit" class="btn btn-sm btn-warning"
                                                    style="color:white"><i class="fas fa-store-alt fa-fw"></i>
                                                    Edit</button>
                                            </form>
                                            <?php else: ?>
                                            <a href="#" class="btn btn-sm btn-warning disabled" style="color:white"><i
                                                    class="fas fa-store-alt fa-fw"></i> Edit</a>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->can('delete-orders')): ?>
                                            <form action="<?php echo e(route('order.destroy', $order)); ?>" class="destroy-order"
                                                style="display:inline-block" method="post">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-danger btn-checked"><i
                                                        class="far fa-trash-alt fa-fw"></i>
                                                    Delete</button>
                                            </form>
                                            <?php else: ?>
                                            <a href="#" class="btn btn-sm btn-danger disabled"><i
                                                    class="far fa-trash-alt fa-fw"></i>
                                                Delete</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div style="margin-top:15px">
                                <?php echo e($orders->appends(['search' => request('search')])->links()); ?>

                            </div>
                            <?php endif; ?>
                    </div>
                    
                </div>
                <!-- End Client list -->
            </div>

            <div class="col-md-5">
                <!-- Order list -->
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h3 class="card-title" style="margin-top: 6px;font-size: 20px; margin-right:10px">
                            <i class="far fa-chart-bar"></i>
                            Order List
                        </h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body" id="order-data">
                    </div>
                    <!-- /.card-body-->
                </div>
                <!-- End Order list -->
            </div>
        </div>

    </section>
</div>
<!--  End Content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>