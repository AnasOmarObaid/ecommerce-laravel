<?php /* E:\Programers\Web-Project\laravelFrameWork\Ecommerce Project\ecommerce\resources\views/layouts/Dashboard/Departments/index.blade.php */ ?>
<?php $__env->startSection('app'); ?>
<?php if(session()->get('successfully')): ?>
<div class="noti-message alert-success"><i class="far fa-check-circle" style="font-size: 14px;"></i>
    <?php echo e(session()->get('successfully')); ?> </div>
<?php endif; ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h2 class="m-0 text-dark">Department</h2>
                <?php echo $__env->make('layouts._includes._error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('dashboard/home')); ?>"><?php echo app('translator')->getFromJson('site.dash'); ?></a></li>
                    <li class="breadcrumb-item">Department</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<div class="container-fluid">
    <?php if(auth()->user()->can(['create-departments|delete-departments|update-departments|read-departments'])): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card" style="overflow: hidden;">
                <div class="card-header" style="position: relative">

                    <h3 class="card-title">Departments Table</h3>
                    <?php if(auth()->user()->can(['create-departments'])): ?>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-success btn-sm" data-toggle="modal"
                        style="cursor: pointer;float: right;" data-target="#exampleModalScrollable">
                        <i class="fas fa-plus-square fa-fw"></i> Add Department
                    </button>
                    <!-- SEARCH FORM -->
                    <form class="form-inline col-md-6" method="get" action="<?php echo e(route('show.department')); ?>">
                        <div class="input-group input-group-sm">
                            <input class="form-control form-control-navbar" type="search" placeholder="Search"
                                aria-label="Search" style="border-right-width: thin;" name="search"
                                value="<?php echo e(request('search')); ?>" required max="20" pattern="[a-z0-9]" />
                            <div class="input-group-append">
                                <button class="btn btn-navbar" type="submit">
                                    <i class="fas fa-search" style="position: absolute;left: -20px;top: 8px;"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Modal -->
                    <div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable" role="document" style="max-width:1000px">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalScrollableTitle">Add Department</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="<?php echo e(route('create.departments')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <div class="modal-body">
                                        <?php echo $__env->make('layouts._includes._error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="form-group">
                                            <label for="dapartment">Department Name:</label>
                                            <input type="text" class="form-control" name='name' value="<?php echo e(old('name')); ?>"
                                                required id="exampleInputEmail1" aria-describedby="department"
                                                placeholder="Department">
                                            <small id="department" class="form-text text-muted">Ensure The The
                                                Department
                                                Name Must Uniqe.</small>
                                        </div>

                                        <div class="form-group">
                                            <label for="dapartment">Department Descarption:</label>
                                            <textarea class="form-control" name='description' required
                                                placeholder="Department Description"
                                                style="height: 160px;"><?php echo e(old('description')); ?></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-block">Save
                                            changes</button>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary btn-sm"
                                            data-dismiss="modal">Close</button>

                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>

                    <?php else: ?>
                    <a class="btn btn-success btn-sm disabled" href="#"
                        style="float: inline-end;margin-bottom: -5px;margin-top: -5px; color:white; cursor:pointer"><i
                            class="fas fa-user-plus fa-fw"></i> Add Department</a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if(count($departments) <= 0): ?> <p> Theres Is No Departments To Show </p>
                        <?php else: ?> <table class="table table-bordered text-center table-hover table-responsive">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <td>Name</td>
                                    <td>Description</td>
                                    <td>Add By</td>
                                    <td>Product Count</td>
                                    <td>status</td>
                                    <td>created_at</td>
                                    <td>updated_at</td>
                                    <td>Mange</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $number = 0 ?>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <th><span><?php echo e(++$number); ?></span></th>
                                    <td>
                                        <span><?php echo e($department->name); ?></span>
                                    </td>
                                    <td><span><?php echo e($department->description); ?></span></td>
                                    <td><span><?php echo e($department->getUser()->first()->email); ?></span>
                                    </td>
                                    <td><?php echo e($department->getProducts->count()); ?></td>
                                    <td>
                                        <?php if($department->status == 1): ?>
                                        <span> Allow </span>
                                        <?php else: ?>
                                        <span> Block </span>
                                        <?php endif; ?>
                                    </td>
                                    <td><span><?php echo e($department->created_at); ?></span></td>
                                    <td><span><?php echo e($department->updated_at); ?></span></td>
                                    <td>
                                        <?php if(auth()->user()->can(['update-departments'])): ?>
                                        <a href="<?php echo e(route('edit.departments', $department)); ?>"
                                            class="btn btn-success btn-sm btn-block" style="margin-bottom:9px">
                                            <i class="fas fa-edit fa-fw"></i>
                                            Edit
                                        </a>
                                        <?php else: ?>
                                        <a href="#" class="btn btn-success btn-sm disabled btn-block"><i
                                                class="fas fa-user-edit fa-fw"></i>
                                            Edit Departmment
                                        </a>
                                        <?php endif; ?>
                                        <?php if(auth()->user()->can(['delete-departments'])): ?>
                                        <form method="POST" action="<?php echo e(route('delete.departments', $department->id)); ?>">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="button" class="btn btn-danger btn-sm btn-block"
                                                style="margin-bottom:9px" data-toggle="modal"
                                                data-target="#example<?php echo e($number); ?>" style="color:white">
                                                <i class="fas fa-trash fa-fw"></i>
                                                <?php echo app('translator')->getFromJson('site.delete'); ?>
                                            </button>
                                            <!-- Modal -->
                                            <div class="modal fade" tabindex="-1" role="dialog" id="example<?php echo e($number); ?>"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Delete
                                                                Department
                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close" class="btn-sm">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Are You Soure To Delete <?php echo e($department->name); ?> <br>
                                                            This Will Lose The Data For This Department
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary btn-sm"
                                                                data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-danger btn-sm">Save
                                                                changes</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                        <?php else: ?>
                                        <a class="btn btn-danger btn-sm disabled btn-block" href="#"><i
                                                class="fas fa-user-minus fa-fw"></i> <?php echo app('translator')->getFromJson('site.delete'); ?></a>
                                        <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div style="margin-top:15px">
                            <?php echo e($departments->appends(['search' => request()->get('search')])->links()); ?>

                        </div>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>

    <div class="container">
        <p class="alert alert-danger"> You Dont Have Permation To Created or See The Departments </p>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>