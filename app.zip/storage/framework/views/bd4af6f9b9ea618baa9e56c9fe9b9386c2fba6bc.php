<?php /* E:\Programers\Web-Project\laravelFrameWork\Ecommerce Project\ecommerce\resources\views/layouts/_includes/notification.blade.php */ ?>
<script>
    $(document).ready(function () {
    "use strict";
        $(".noti-message").animate({
            right: "0"
        }, 2000, function () {
            $(this).delay(6000).animate({
                right: "-593px"
            }, 2000);
        });
    });
</script>