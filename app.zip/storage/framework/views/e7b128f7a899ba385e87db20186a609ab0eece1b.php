<?php /* C:\xampp\htdocs\EcommerceProject\ecommerce\resources\views/layouts/Dashboard/Clint/Order/create.blade.php */ ?>
<?php $__env->startSection('app'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <?php if(session()->get('successfully')): ?>
    <div class="noti-message alert-success"><i class="far fa-check-circle" style="font-size: 14px;"></i>
        <?php echo e(session()->get('successfully')); ?>

    </div>
    <?php endif; ?>
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h2 class="m-0 text-dark">Add Order</h2>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('dashboard/home')); ?>"><?php echo app('translator')->getFromJson('site.dash'); ?></a></li>
                    <li class="breadcrumb-item">Orders</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<div class="container-fluid">
    <section class="order-content">
        <div class="row">

            <div class="col-md-6">
                <!-- department list -->
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="far fa-chart-bar"></i>
                            Departments List
                        </h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(count($departments) <= 0 ): ?> <p class=" alert alert-danger">There Is No Departments To Add
                            Orders
                            </p>
                            <?php else: ?>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="card card-info">
                                <div class="card-header" data-toggle="collapse"
                                    href="#<?php echo e(str_replace(' ', '-', $department->name)); ?>" role="button"
                                    aria-expanded="false" aria-controls="1" style="cursor:pointer">
                                    <h3 class="card-title"> <?php echo e($department->name); ?></h3>
                                </div>
                                <div class="collapse" id="<?php echo e(str_replace(' ', '-', $department->name)); ?>">
                                    <div class="card-body">
                                        <?php if($department->getProducts()->count() == 0): ?>
                                        <p class="alert alert-danger">There Is No Product</p>
                                        <?php else: ?>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Stock</th>
                                                    <th scope="col">Price</th>
                                                    <th scope="col">Add</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $department->getProducts()->where('stock', '>',
                                                1)->where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="product-<?php echo e($product->id); ?>">
                                                    <td><span><?php echo e($product->name); ?></span></td>
                                                    <td><span
                                                            id="stock-product<?php echo e($product->id); ?>"><?php echo e($product->stock); ?></span>
                                                    </td>
                                                    <td><span class="span-price"><?php echo e($product->sale_price); ?></span></td>
                                                    <td>
                                                        <a href="#" class="btn btn-sm btn-success product-data"
                                                            id="link-product<?php echo e($product->id); ?>"
                                                            data-name="<?php echo e($product->name); ?>" data-id="<?php echo e($product->id); ?>"
                                                            data-price="<?php echo e($product->sale_price); ?>"
                                                            data-quantity="<?php echo e($product->stock); ?>">
                                                            <i class="fas fa-plus fa-fw"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                    </div>
                    <!-- /.card-body-->
                </div>
                <!-- End department list -->
            </div>

            <div class="col-md-6">
                <!-- order list -->
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="far fa-chart-bar"></i>
                            Order List
                        </h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <form id="order-submit" method="POST" action="<?php echo e(route('client.store.order', $user_id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col"><span>product</span></th>
                                        <th scope="col"><span>Quantity</span></th>
                                        <th scope="col"><span>Price</span></th>
                                    </tr>
                                </thead>
                                <thead class="table-head">

                                </thead>
                            </table>
                            <h5 style="margin-top:12px">Total: <span id="total-price"></span></h5>
                            <button type="submit" class="btn btn-info btn-block disabled btn-submit">Add
                                Product</button>
                        </form>
                    </div>
                    <!-- /.card-body-->
                </div>
                <!-- End order list -->
            </div>
        </div>
        <!-- order previous list -->
        <div class="row">
            <div class="col-md-6">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="far fa-chart-bar"></i>
                            order previous list
                        </h3>
                        <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                    class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(count($orders) == 0): ?>
                        <p class="alert alert-danger">There Is No Orders For This Client</p>
                        <?php else: ?>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card card-info">
                            <div class="card-header" data-toggle="collapse" href="#order<?php echo e($order->id); ?>" role="button"
                                aria-expanded="false" aria-controls="1" style="cursor:pointer">
                                Order Number <?php echo e($index); ?>

                            </div>

                            <div class="collapse" id="order<?php echo e($order->id); ?>">
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                            <td>Name</td>
                                            <td>total price</td>
                                            <td>Quantity</td>
                                            <td>Date</td>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><?php echo e($order->getProduct()->first()->name); ?></td>
                                                <td><?php echo e($order->total_price); ?></td>
                                                <td><?php echo e($order->quantity); ?></td>
                                                <td><?php echo e($order->created_at->toFormattedDateString()); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <!-- /.card-body-->
                </div>
                <!-- End order previous list -->
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>